

import java.awt.Color;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.WindowEvent;
import javax.swing.*;
import java.util.Timer;
import java.awt.Graphics;
//import javax.swing.Timer;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import javax.swing.JFrame;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

import java.util.*;

public class GameStart extends JPanel {
   //private static MazeGenerator map= null;
   private static Wizard wiz;
   static CombatInitiator startCombat;
   static Scanner c= new Scanner(System.in);
   public static int [][] north;
   public static int [][] south;
   public static int [][] west;
   public static int [][] east;
   public static int [][] items;
   public static boolean [][] light;
   public static ArrayList<MazeGenerator> mapList = new ArrayList<MazeGenerator>();
   public static int currentMap=0; 
   static int[] stairs;
   static int width;
   public static boolean draw=false;
   static int height;
   static int maxHeight=21;
   static int maxWidth=22;
   static int minHeight=10;
   static int minWidth=11;
   static String input;
   public static boolean combat=false;
   static int counter=0;
   static int movingl=0;
   static int movingu=0;
   static ImageIcon player;
   static ImageIcon stairsUp = new ImageIcon("pictures\\stairsup.png");
   static ImageIcon stairsDown = new ImageIcon("pictures\\stairsdown.png");
   static ImageIcon wall = new ImageIcon("pictures\\wall3.jpg");
   static ImageIcon fog = new ImageIcon("pictures\\fog.jpg");
   static Color wallColor = new Color(0,0,0);
   static Color fogColor = new Color(100,100,100);
   public static JFrame frame; 
   public void paint(Graphics g) 
   {
      Scanner c= new Scanner(System.in);
     //print background wall
      Graphics2D g2d = (Graphics2D) g;
      //g2d.setColor(new Color(127,255,0));
      g2d.setColor(wallColor);	
      for (int y=0;y<(height)/2;y++)
      {
         for (int x=0;x<(width)/2;x++)
         {
         
            g2d.drawImage(wall.getImage(),x*100,y*100,100,100,null);
         }
         
      }	
      g2d.fillRect(0,0,26,height*50);
      g2d.fillRect(0,0,width*50,26);
      g2d.fillRect(width*50-74,0,25,height*50);
      g2d.fillRect(0,height*50-74,width*50,25);
      for (int y=1;y<height-1;y++)
      {
         for (int x=1;x<width-1;x++)
         {
            if (!light[y][x])
            {
               g2d.setColor(fogColor);
            }
            
            else
               g2d.setColor(wallColor);
            if (!light[y][x])
            {
               g2d.fillRect(x*50-24,y*50-24,50,50);
            }
            // east wall
            //g2d.setColor(Color.BLACK);
            if (east[y][x]==1)
               g2d.fillRect(x*50+25,y*50-25,1,50);
            // North
            
            //g2d.setColor(Color.BLUE);
            if (north[y][x]==1)
               g2d.fillRect(x*50-25,y*50-25,50,2);
            // South
            
            //g2d.setColor(Color.GREEN);
            if (south[y][x]==1)
               g2d.fillRect(x*50-25,y*50+24,50,2);
            // West
            //g2d.setColor(new Color(127,255,0));
            if (west[y][x]==1)
               g2d.fillRect(x*50-24,y*50-25,1,50);
            
            
         }
      }
      //sux,suy,sdx,sdy
      if (light[stairs[3]][stairs[2]])
         g2d.drawImage(stairsDown.getImage(),stairs[2]*50-25,stairs[3]*50-23,48,48,null);
      if (light[stairs[1]][stairs[0]])
         g2d.drawImage(stairsUp.getImage(),stairs[0]*50-25,stairs[1]*50-23,48,48,null);
      //if (movingr>0||movingu>0)
      int wizplacex=wiz.getX()*50-25+movingl;
      int wizplacey=wiz.getY()*50-23+movingu;
      g2d.drawImage(player.getImage(),wizplacex,wizplacey,48,48,null);
   }
	
    // 1 means wall
         // 0 means empty
   public int[][] getNorth()
   {
      return north;
   }
   public int[][] getEast()
   {
      return east;
   }
   public int[][] getSouth()
   {
      return south;
   }
   public int[][] getWest()
   {
      return west;
   }
   public static void changeLevel()
   {
      north=mapList.get(currentMap).getNorth();
      south=mapList.get(currentMap).getSouth();
      west=mapList.get(currentMap).getWest();
      east=mapList.get(currentMap).getEast();
      height=mapList.get(currentMap).getHeight();
      width=mapList.get(currentMap).getWidth();
      stairs=mapList.get(currentMap).getStairs();
      items=mapList.get(currentMap).getItems();
      light = new boolean[north.length][north[1].length];
      //System.out.println(stairs[0]+" "+stairs[1]+" "+stairs[2]+" "+ stairs[3]);
      //System.out.println(currentMap+" is "+width+" "+height + " compared "+mapList.get(currentMap).getWidth()+" "+mapList.get(currentMap).getHeight());
     // mapList.get(currentMap).printWalls();
   }
   public static void newMap(int h, int w)
   {
      height=h;
      width=w;
      light = new boolean[h][w];
    //MazeGenerator map= new MazeGenerator(width,height);
      //map.setName("map " + mapList.size());
      //mapList.add(new MazeGenerator());
      mapList.add(new MazeGenerator(width,height,"map "+mapList.size()));
      //mapList.get(currentMap).startingItems();
      //mapList.get(mapList.size()-1)=new MazeGenerator(width,height,"map "+mapList.size());
      //map=null;
      
      //System.out.println(
      //counter++;
      height=mapList.get(mapList.size()-1).getHeight();
      width=mapList.get(mapList.size()-1).getWidth();
      
      changeLevel();
      /*if (mapList.get(currentMap).getName().equals("map 0"))
      {
         for(int x=0;x<items[0].length;x++)
         {
            for(int y=0;y<items.length;y++)
            {
            if(items[y][x]==1)
            items[y][x]=1;
            }
         }
      }*/
      
   }
   public static void goUp()
   {
      if (currentMap==0)
      {
         System.out.println("Do you really want to leave the dungeon? y/n");
         String input = c.next();
         if (input.equals("y"))
         {
            System.out.println("Goodbye, we hope you had fun, come again!!");
            System.exit(0);
         }
      }
      else
      {
         currentMap--;
         changeLevel();
         wiz.setXY(stairs[2],stairs[3]);
      }
   }
   public static void goDown()
   {
      currentMap++;
      if (currentMap==mapList.size())
      {
         int tempHeight=(int)(Math.random()*(maxHeight-minHeight)+minHeight+1);
         int tempWidth=(int)(Math.random()*(maxWidth-minWidth)+minWidth+1);
         newMap(tempHeight,tempWidth);
      }
      else 
         changeLevel();
      wiz.setXY(stairs[0],stairs[1]);
         
   }
  
   public static void combat()
   {
      frame.setVisible(false);
      if (startCombat.startCombat("Lion"));
      startCombat.endCombat();
      frame.setVisible(true);
   }
   public static void printing()
   {
      for(int i=0;i<mapList.size();i++)
      {
         mapList.get(i).printWalls();
      }
   }
   public static void draw()
   {
      if (!draw)
      {
         for (int x=0;x<light.length;x++)
         {
            for (int y=0;y<light[0].length;y++)
            {
               light[x][y]=true;
            }
         }
         draw=true;
      } 
      else 
         draw=false;
   }
   public static void move(String mover)
   {
      int steps=0;
      if (wiz.go(mover))
      {
      
         if (mover.equals("south")||mover.equals("down")||mover.equals("s"))
            movingu=-1*steps;
         else if (mover.equals("up")||mover.equals("north")||mover.equals("n"))
            movingu=steps;
         else if (mover.equals("east")||mover.equals("right")||mover.equals("e"))
            movingl=-1*steps;
         else if (mover.equals("left")||mover.equals("west")||mover.equals("w"))
            movingl=steps;
      //ActionListener action = new ActionListener();
      /*Timer t = new Timer();
      t.setRepeats(true);
      t.setDelay(10);
      t.start();*/
      
         Timer timer = new Timer();
         timer.scheduleAtFixedRate(
               new TimerTask() {
               
                  @Override
                  public void run() {
                     refresh();
                     if (movingl>0)
                        movingl--;
                     if (movingl<0)
                        movingl++;
                     if (movingu>0)
                        movingu--;
                     if (movingu<0)
                        movingu++;
                  
                  }
               }, 0,150);
         timer.purge();
      
      
      }
   }
   public static void refresh()
   {
      doLighting();
      frame.repaint();
      
   }
   public static void doLighting()
   {
      if (!draw)
      {
         int tempx=wiz.getX(),tempy=wiz.getY(),counter=0;
         boolean waller = true;
         for (int x=0;x<light.length;x++)
         {
            for (int y=0;y<light[0].length;y++)
            {
               light[x][y]=false;
            }
         }
         light[wiz.getY()][wiz.getX()]=true;
         int max=3;
         for (int x=0;x<4;x++)
         {//0=down, 1=up, 2=left, 3=right
            tempx=wiz.getX();
            tempy=wiz.getY();
            counter=0;
            int tempCount;
            waller=true;
            if (x==0)
            {
            // south
               while(counter<max&&south[tempy][tempx]==0)
               {
                  tempy++;
                  light[tempy][tempx]=true;
                  tempCount=0;
                  while(tempCount<max-counter-1)
                  {
                     if (east[tempy][tempx+tempCount]==0)
                        light[tempy][tempx+tempCount+1]=true;
                     else 
                        tempCount=max-counter;
                     tempCount++;
                  }
                  tempCount=0;
                  while(tempCount<max-counter-1)
                  {  
                     
                     if (west[tempy][tempx-tempCount]==0)
                        light[tempy][tempx-tempCount-1]=true;
                     else 
                        tempCount=max-counter;
                     tempCount++;
                  }
                  counter++;
               }
            }
            else if (x==1)
            {
            //north
               while(counter<max&&north[tempy][tempx]==0)
               {
                  tempy--;
                  light[tempy][tempx]=true;
                  tempCount=0;
                  while(tempCount<max-counter-1)
                  {
                     if (east[tempy][tempx+tempCount]==0)
                        light[tempy][tempx+tempCount+1]=true;
                     else 
                        tempCount=max-counter;
                     tempCount++;
                  }
                  tempCount=0;
                  while(tempCount<max-counter-1)
                  {
                     if (west[tempy][tempx-tempCount]==0)
                        light[tempy][tempx-tempCount-1]=true;
                     else 
                        tempCount=max-counter; 
                     tempCount++;                   
                  }
                  counter++;
               }
            }
            else if (x==2)
            {//west
               while(counter<max&&west[tempy][tempx]==0)
               {
                  tempx--;
                  light[tempy][tempx]=true;
                  tempCount=0;
                  while(tempCount<max-counter-1)
                  {
                     if (north[tempy-tempCount][tempx]==0)
                        light[tempy-tempCount-1][tempx]=true;
                     else 
                        tempCount=max-counter;
                     tempCount++;
                  }
                  tempCount=0;
                  while(tempCount<max-counter-1)
                  {
                     if (south[tempy+tempCount][tempx]==0)
                        light[tempy+tempCount+1][tempx]=true;
                     else 
                        tempCount=max-counter;
                     tempCount++;
                  }
                  counter++;
               }
            }
            else if (x==3)
            {//east
               while(counter<max&&east[tempy][tempx]==0)
               {
                  tempx++;
                  light[tempy][tempx]=true;
                  tempCount=0;
                  while(tempCount<max-counter-1)
                  {
                     if (north[tempy-tempCount][tempx]==0)
                        light[tempy-tempCount-1][tempx]=true;
                     else 
                        tempCount=max-counter;
                     tempCount++;
                  }
                  tempCount=0;
                  while(tempCount<max-counter-1)
                  {
                     if (south[tempy+tempCount][tempx]==0)
                        light[tempy+tempCount+1][tempx]=true;
                     else 
                        tempCount=max-counter;
                     tempCount++;
                  }
                  counter++;
               }
            }
            
         }
         
      }
   
   }
   public static void main(String[] args) 
   {
      //mapList= new ArrayList<MazeGenerator>();
      Scanner c= new Scanner(System.in);
      newMap(10,15);
      wiz= new Wizard(width,height);
      //t.printWalls();
      player = wiz.getPic();
      frame = new JFrame("Dungeon");
      frame.add(new Game2());
      int windowx=width*50-50*3/4;
      int windowy=height*50-50/4;
      frame.setSize(windowx,windowy);
      frame.setLocation(1280/2-windowx/2, 1024/2-windowy/2);
      frame.setVisible(true);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      int waiting=0;
      input="";
      while (!input.equals("exit"))
      {
         if (combat)
            System.out.println("test");
         if (combat)
            frame.setVisible(false);
         else 
            frame.setVisible(true);
                  
       //System.out.println(wiz.getEnergy());
         //int waiting=0;
         
         if (waiting==0&&!combat)
         {
            refresh();
            input = c.next();
            //wiz.restoreEnergy();
            //System.out.println("hello there");
            switch(input)
            {
               case "move":
               case "go":
                  String movement=c.next();
                  move(movement);
                  
                  break;
               case "up":
               case "w":
                  move("up");
                  break;
               case "down":
               case "s":
                  move("down");
                  break;
               case "left":
               case "a":
                  move("left");
                  break;
               case "right":
               case "d":
                  move("right");
                  break;
               case "teleport":
                  System.out.println("You were at "+wiz.getX()+","+wiz.getY());
                  wiz.teleport(c.nextInt(),c.nextInt());
                  
                  break;
               case "wait":
                  case "sleep":
                  case "rest":
                  waiting=(int)(c.nextDouble());
                  System.out.println("You are resting");
                  break;
               case "help":
                  case "?":
                  System.out.println ("move/go \n teleport \n rest/sleep/wait \n stairs");
                  break;
               case "stairs":
                  //System.out.println(wiz.getY()+" "+wiz.getX()+" "+items[wiz.getY()][wiz.getX()]);
                  if(items[wiz.getY()][wiz.getX()]==2)
                     goDown();
                  else if (items[wiz.getY()][wiz.getX()]==1)
                     goUp();
                  
                  break;
               case "repaint":
                  refresh();
                  break;
               case "print":
                  printing();
                  break;
               case "draw":
                  draw();
                  break;
               case "test":
                  combat();
                  break;
            
            }
            refresh();
         
         
         
            
         }
         else 
         {
            
            waiting--;
         }
         wiz.restoreEnergy();
         windowx=width*50-50*3/4;
         windowy=height*50-50/4;
         frame.setSize(windowx,windowy);
         frame.setLocation(1280/2-windowx/2, 1024/2-windowy/2);
      
         //frame.repaint();
      }
      System.out.println("test2");
      System.exit(0);
   }
}